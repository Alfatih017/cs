# config.py
# File ini berisi konfigurasi utama untuk bot Telegram

TELEGRAM_BOT_TOKEN = "7377213401:AAFewcDjnyIvJObTENP-fp5G9Mi7a_gex7Y"  # Ganti dengan token bot Anda
ADMIN_USER_ID = 6664945344  # Ganti dengan ID Telegram Anda
CACHE_EXPIRATION = 30000  # Waktu kedaluwarsa cache dalam detik (5 menit)
COINSTORE_API_URL = "https://api.coinstore.com/api"  # URL dasar API Coinstore