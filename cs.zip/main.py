import logging
from telegram.ext import Updater, CommandHandler, CallbackQueryHandler, MessageHandler, Filters
from config import TELEGRAM_BOT_TOKEN
from bot.handlers import start, admin_command, menu_command, callback_handler, message_handler, error_handler

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

def main():
    global logger
    logger = setup_logging()

    updater = Updater(TELEGRAM_BOT_TOKEN, use_context=True)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(CommandHandler("admin", admin_command))
    dp.add_handler(CommandHandler("menu", menu_command))
    dp.add_handler(CallbackQueryHandler(callback_handler))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, message_handler))

    dp.add_error_handler(error_handler)

    logger.info("Bot started")
    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()