import sqlite3

def init_db():
    conn = sqlite3.connect('bot_database.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS authorized_users
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id INTEGER UNIQUE)''')
    c.execute('''CREATE TABLE IF NOT EXISTS accounts
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id INTEGER,
                  name TEXT,
                  api_key TEXT,
                  secret_key TEXT)''')
    c.execute('''CREATE TABLE IF NOT EXISTS tokens
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id INTEGER,
                  name TEXT,
                  symbol TEXT)''')
    conn.commit()
    conn.close()

def add_authorized_user(user_id):
    conn = sqlite3.connect('bot_database.db')
    c = conn.cursor()
    c.execute("INSERT OR IGNORE INTO authorized_users (user_id) VALUES (?)", (user_id,))
    conn.commit()
    conn.close()

def remove_authorized_user(user_id):
    conn = sqlite3.connect('bot_database.db')
    c = conn.cursor()
    c.execute("DELETE FROM authorized_users WHERE user_id = ?", (user_id,))
    conn.commit()
    conn.close()

def is_user_authorized(user_id):
    conn = sqlite3.connect('bot_database.db')
    c = conn.cursor()
    c.execute("SELECT 1 FROM authorized_users WHERE user_id = ?", (user_id,))
    result = c.fetchone() is not None
    conn.close()
    return result

def add_account(user_id, name, api_key, secret_key):
    conn = sqlite3.connect('bot_database.db')
    c = conn.cursor()
    c.execute("INSERT INTO accounts (user_id, name, api_key, secret_key) VALUES (?, ?, ?, ?)",
              (user_id, name, api_key, secret_key))
    conn.commit()
    conn.close()

def edit_account(user_id, account_id, name, api_key, secret_key):
    conn = sqlite3.connect('bot_database.db')
    c = conn.cursor()
    c.execute("UPDATE accounts SET name = ?, api_key = ?, secret_key = ? WHERE id = ? AND user_id = ?",
              (name, api_key, secret_key, account_id, user_id))
    conn.commit()
    conn.close()

def delete_account(user_id, account_id):
    conn = sqlite3.connect('bot_database.db')
    c = conn.cursor()
    c.execute("DELETE FROM accounts WHERE id = ? AND user_id = ?", (account_id, user_id))
    conn.commit()
    conn.close()

def get_all_accounts(user_id):
    conn = sqlite3.connect('bot_database.db')
    c = conn.cursor()
    c.execute("SELECT id, name, api_key, secret_key FROM accounts WHERE user_id = ?", (user_id,))
    accounts = [{'id': row[0], 'name': row[1], 'api_key': row[2], 'secret_key': row[3]} for row in c.fetchall()]
    conn.close()
    return accounts

def add_token(user_id, name, symbol):
    conn = sqlite3.connect('bot_database.db')
    c = conn.cursor()
    c.execute("INSERT INTO tokens (user_id, name, symbol) VALUES (?, ?, ?)",
              (user_id, name, symbol))
    conn.commit()
    conn.close()

def edit_token(user_id, token_id, name, symbol):
    conn = sqlite3.connect('bot_database.db')
    c = conn.cursor()
    c.execute("UPDATE tokens SET name = ?, symbol = ? WHERE id = ? AND user_id = ?",
              (name, symbol, token_id, user_id))
    conn.commit()
    conn.close()

def delete_token(user_id, token_id):
    conn = sqlite3.connect('bot_database.db')
    c = conn.cursor()
    c.execute("DELETE FROM tokens WHERE id = ? AND user_id = ?", (token_id, user_id))
    conn.commit()
    conn.close()

def get_all_tokens(user_id):
    conn = sqlite3.connect('bot_database.db')
    c = conn.cursor()
    c.execute("SELECT id, name, symbol FROM tokens WHERE user_id = ?", (user_id,))
    tokens = [{'id': row[0], 'name': row[1], 'symbol': row[2]} for row in c.fetchall()]
    conn.close()
    return tokens

# database/db_operations.py (tambahan fungsi)

def get_account_by_id(user_id, account_id):
    """Mengambil informasi akun berdasarkan ID."""
    conn = sqlite3.connect('bot_database.db')
    c = conn.cursor()
    c.execute("SELECT id, name, api_key, secret_key FROM accounts WHERE user_id = ? AND id = ?", (user_id, account_id))
    account = c.fetchone()
    conn.close()
    if account:
        return {'id': account[0], 'name': account[1], 'api_key': account[2], 'secret_key': account[3]}
    return None

def get_token_by_id(user_id, token_id):
    """Mengambil informasi token berdasarkan ID."""
    conn = sqlite3.connect('bot_database.db')
    c = conn.cursor()
    c.execute("SELECT id, name, symbol FROM tokens WHERE user_id = ? AND id = ?", (user_id, token_id))
    token = c.fetchone()
    conn.close()
    if token:
        return {'id': token[0], 'name': token[1], 'symbol': token[2]}
    return None

init_db()
</antArtifact>