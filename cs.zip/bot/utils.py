# bot/utils.py (file baru untuk fungsi-fungsi utilitas)

def validate_amount(amount_str):
    """Memvalidasi format jumlah withdraw."""
    try:
        min_amount, max_amount = map(float, amount_str.split('-'))
        if min_amount <= 0 or max_amount <= 0:
            return False, "Jumlah harus lebih besar dari 0."
        if min_amount >= max_amount:
            return False, "Jumlah minimum harus lebih kecil dari jumlah maksimum."
        return True, None
    except ValueError:
        return False, "Format jumlah tidak valid. Gunakan format: min-max (contoh: 100-500)"

def validate_address(address):
    """Memvalidasi format alamat withdraw."""
    # Implementasikan validasi sesuai dengan format alamat yang valid untuk platform Anda
    if len(address) < 10:  # Contoh sederhana, sesuaikan dengan kebutuhan
        return False, "Alamat tidak valid. Alamat harus memiliki minimal 10 karakter."
    return True, None