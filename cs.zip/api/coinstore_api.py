# bot/coinstore_api.py
# File ini berisi fungsi-fungsi untuk berinteraksi dengan API Coinstore

import hashlib
import hmac
import json
import math
import time
import requests
from config import COINSTORE_API_URL
from bot.cache import cache

def generate_signature(api_key, secret_key, payload):
    """Menghasilkan signature untuk autentikasi API Coinstore."""
    expires = int(time.time() * 1000)
    expires_key = str(math.floor(expires / 30000))
    expires_key = expires_key.encode("utf-8")
    key = hmac.new(secret_key.encode(), expires_key, hashlib.sha256).hexdigest()
    key = key.encode("utf-8")
    
    payload = json.dumps(payload).encode("utf-8")
    signature = hmac.new(key, payload, hashlib.sha256).hexdigest()
    
    headers = {
        'X-CS-APIKEY': api_key,
        'X-CS-SIGN': signature,
        'X-CS-EXPIRES': str(expires),
        'exch-language': 'en_US',
        'Content-Type': 'application/json',
        'Accept': '*/*',
        'Connection': 'keep-alive'
    }
    
    return headers, payload

def get_account_balance(api_key, secret_key):
    """Mengambil saldo akun dari API Coinstore dengan caching."""
    cache_key = f"balance_{api_key}"
    cached_data = cache.get(cache_key)
    if cached_data:
        return cached_data

    url = f"{COINSTORE_API_URL}/spot/accountList"
    payload = {}
    headers, payload = generate_signature(api_key, secret_key, payload)
    
    response = requests.post(url, headers=headers, data=payload)
    response_data = response.json()
    
    if response.status_code == 200 and response_data.get('code') == 0:
        balance_data = response_data['data']
        cache.set(cache_key, balance_data)
        return balance_data
    else:
        raise Exception(f"API Error: {response_data.get('msg', 'Unknown error')}")

def withdraw(api_key, secret_key, currency_code, amount, address, tag=None, chain_type=None):
    """Melakukan penarikan (withdraw) melalui API Coinstore."""
    url = f"{COINSTORE_API_URL}/fi/v3/asset/doWithdraw"
    payload = {
        "currencyCode": currency_code,
        "amount": str(amount),
        "address": address
    }
    if tag:
        payload["tag"] = tag
    if chain_type:
        payload["chainType"] = chain_type

    headers, payload = generate_signature(api_key, secret_key, payload)
    
    response = requests.post(url, headers=headers, data=payload)
    response_data = response.json()
    
    if response.status_code == 200 and response_data.get('code') == 0:
        return response_data['data']
    else:
        raise Exception(f"API Error: {response_data.get('msg', 'Unknown error')}")