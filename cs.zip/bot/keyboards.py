# bot/keyboards.py

from telegram import InlineKeyboardButton, InlineKeyboardMarkup

def get_main_menu_keyboard():
    keyboard = [
        [InlineKeyboardButton("Manajemen Akun", callback_data='account_management')],
        [InlineKeyboardButton("Manajemen Token", callback_data='token_management')],
        [InlineKeyboardButton("Withdraw", callback_data='withdraw')],
        [InlineKeyboardButton("Pengaturan", callback_data='settings')]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_account_management_keyboard():
    keyboard = [
        [InlineKeyboardButton("Tambah Akun", callback_data='add_account')],
        [InlineKeyboardButton("Edit Akun", callback_data='edit_account')],
        [InlineKeyboardButton("Hapus Akun", callback_data='delete_account')],
        [InlineKeyboardButton("Lihat Semua Akun", callback_data='view_accounts')],
        [InlineKeyboardButton("Kembali ke Menu Utama", callback_data='main_menu')]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_token_management_keyboard():
    keyboard = [
        [InlineKeyboardButton("Tambah Token", callback_data='add_token')],
        [InlineKeyboardButton("Edit Token", callback_data='edit_token')],
        [InlineKeyboardButton("Hapus Token", callback_data='delete_token')],
        [InlineKeyboardButton("Lihat Semua Token", callback_data='view_tokens')],
        [InlineKeyboardButton("Kembali ke Menu Utama", callback_data='main_menu')]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_settings_keyboard():
    keyboard = [
        [InlineKeyboardButton("Lihat Saldo", callback_data='view_balance')],
        [InlineKeyboardButton("Reset Cache", callback_data='reset_cache')],
        [InlineKeyboardButton("Kembali ke Menu Utama", callback_data='main_menu')]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_admin_keyboard():
    keyboard = [
        [InlineKeyboardButton("Tambah Pengguna", callback_data='add_user')],
        [InlineKeyboardButton("Hapus Pengguna", callback_data='remove_user')],
        [InlineKeyboardButton("Reset Cache", callback_data='reset_cache')],
        [InlineKeyboardButton("Kembali ke Menu Utama", callback_data='main_menu')]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_confirm_keyboard():
    keyboard = [
        [InlineKeyboardButton("Ya", callback_data='confirm_yes')],
        [InlineKeyboardButton("Tidak", callback_data='confirm_no')]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_back_keyboard(callback_data='main_menu'):
    keyboard = [[InlineKeyboardButton("Kembali", callback_data=callback_data)]]
    return InlineKeyboardMarkup(keyboard)