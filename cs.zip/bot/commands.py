# bot/commands.py

from telegram import Update
from telegram.ext import CallbackContext
from bot.keyboards import get_main_menu_keyboard

def start(update: Update, context: CallbackContext):
    update.message.reply_text('Selamat datang di Bot Withdrawal! Gunakan /menu untuk melihat opsi yang tersedia.')

def menu(update: Update, context: CallbackContext):
    keyboard = get_main_menu_keyboard()
    update.message.reply_text('Menu Utama:', reply_markup=keyboard)

def help_command(update: Update, context: CallbackContext):
    help_text = """
    Selamat datang di Bot Withdrawal!
    
    Perintah yang tersedia:
    /start - Memulai bot
    /menu - Menampilkan menu utama
    /help - Menampilkan pesan bantuan ini
    
    Gunakan menu untuk mengakses fitur-fitur berikut:
    - Manajemen Akun
    - Manajemen Token
    - Withdraw
    - Pengaturan
    
    Untuk bantuan lebih lanjut, silakan hubungi admin.
    """
    update.message.reply_text(help_text)