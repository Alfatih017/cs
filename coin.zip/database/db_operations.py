# database/db_operations.py

import aiosqlite
from config import ADMIN_USER_ID

async def init_db():
    async with aiosqlite.connect('bot_database.db') as db:
        await db.execute('''CREATE TABLE IF NOT EXISTS authorized_users
                            (id INTEGER PRIMARY KEY AUTOINCREMENT,
                             user_id INTEGER UNIQUE)''')
        await db.execute('''CREATE TABLE IF NOT EXISTS accounts
                            (id INTEGER PRIMARY KEY AUTOINCREMENT,
                             user_id INTEGER,
                             name TEXT,
                             api_key TEXT,
                             secret_key TEXT)''')
        await db.execute('''CREATE TABLE IF NOT EXISTS tokens
                            (id INTEGER PRIMARY KEY AUTOINCREMENT,
                             user_id INTEGER,
                             name TEXT,
                             symbol TEXT)''')
        
        # Add admin user if not exists
        await db.execute("INSERT OR IGNORE INTO authorized_users (user_id) VALUES (?)", (ADMIN_USER_ID,))
        await db.commit()

async def add_authorized_user(user_id: int):
    async with aiosqlite.connect('bot_database.db') as db:
        await db.execute("INSERT OR IGNORE INTO authorized_users (user_id) VALUES (?)", (user_id,))
        await db.commit()

async def remove_authorized_user(user_id: int):
    async with aiosqlite.connect('bot_database.db') as db:
        await db.execute("DELETE FROM authorized_users WHERE user_id = ?", (user_id,))
        await db.commit()

async def is_user_authorized(user_id: int):
    async with aiosqlite.connect('bot_database.db') as db:
        async with db.execute("SELECT 1 FROM authorized_users WHERE user_id = ?", (user_id,)) as cursor:
            return await cursor.fetchone() is not None

async def add_account(user_id: int, name: str, api_key: str, secret_key: str):
    async with aiosqlite.connect('bot_database.db') as db:
        await db.execute("INSERT INTO accounts (user_id, name, api_key, secret_key) VALUES (?, ?, ?, ?)",
                         (user_id, name, api_key, secret_key))
        await db.commit()

async def edit_account(user_id: int, account_id: int, name: str, api_key: str, secret_key: str):
    async with aiosqlite.connect('bot_database.db') as db:
        await db.execute("UPDATE accounts SET name = ?, api_key = ?, secret_key = ? WHERE id = ? AND user_id = ?",
                         (name, api_key, secret_key, account_id, user_id))
        await db.commit()

async def delete_account(user_id: int, account_id: int):
    async with aiosqlite.connect('bot_database.db') as db:
        await db.execute("DELETE FROM accounts WHERE id = ? AND user_id = ?", (account_id, user_id))
        await db.commit()

async def get_all_accounts(user_id: int):
    async with aiosqlite.connect('bot_database.db') as db:
        async with db.execute("SELECT id, name, api_key, secret_key FROM accounts WHERE user_id = ?", (user_id,)) as cursor:
            return [{'id': row[0], 'name': row[1], 'api_key': row[2], 'secret_key': row[3]} for row in await cursor.fetchall()]

async def add_token(user_id: int, name: str, symbol: str):
    async with aiosqlite.connect('bot_database.db') as db:
        await db.execute("INSERT INTO tokens (user_id, name, symbol) VALUES (?, ?, ?)",
                         (user_id, name, symbol))
        await db.commit()

async def edit_token(user_id: int, token_id: int, name: str, symbol: str):
    async with aiosqlite.connect('bot_database.db') as db:
        await db.execute("UPDATE tokens SET name = ?, symbol = ? WHERE id = ? AND user_id = ?",
                         (name, symbol, token_id, user_id))
        await db.commit()

async def delete_token(user_id: int, token_id: int):
    async with aiosqlite.connect('bot_database.db') as db:
        await db.execute("DELETE FROM tokens WHERE id = ? AND user_id = ?", (token_id, user_id))
        await db.commit()

async def get_all_tokens(user_id: int):
    async with aiosqlite.connect('bot_database.db') as db:
        async with db.execute("SELECT id, name, symbol FROM tokens WHERE user_id = ?", (user_id,)) as cursor:
            return [{'id': row[0], 'name': row[1], 'symbol': row[2]} for row in await cursor.fetchall()]

async def get_token_by_id(user_id: int, token_id: int):
    async with aiosqlite.connect('bot_database.db') as db:
        async with db.execute("SELECT id, name, symbol FROM tokens WHERE id = ? AND user_id = ?", (token_id, user_id)) as cursor:
            row = await cursor.fetchone()
            return {'id': row[0], 'name': row[1], 'symbol': row[2]} if row else None

async def get_account_by_id(user_id: int, account_id: int):
    async with aiosqlite.connect('bot_database.db') as db:
        async with db.execute("SELECT id, name, api_key, secret_key FROM accounts WHERE id = ? AND user_id = ?", (account_id, user_id)) as cursor:
            row = await cursor.fetchone()
            return {'id': row[0], 'name': row[1], 'api_key': row[2], 'secret_key': row[3]} if row else None
