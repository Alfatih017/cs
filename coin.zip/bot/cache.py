# bot/cache.py

import time
from threading import Lock
from typing import Any, Dict

class SimpleCache:
    def __init__(self, default_expiration: int = 300):
        self.cache: Dict[str, Dict[str, Any]] = {}
        self.default_expiration = default_expiration
        self.lock = Lock()

    def set(self, key: str, value: Any, expiration: int = None) -> None:
        """
        Menyimpan nilai dalam cache.
        
        :param key: Kunci untuk menyimpan nilai
        :param value: Nilai yang akan disimpan
        :param expiration: Waktu kedaluwarsa dalam detik (opsional)
        """
        if expiration is None:
            expiration = self.default_expiration

        with self.lock:
            self.cache[key] = {
                'value': value,
                'expiration': time.time() + expiration
            }

    def get(self, key: str) -> Any:
        """
        Mengambil nilai dari cache.
        
        :param key: Kunci untuk mengambil nilai
        :return: Nilai yang tersimpan atau None jika tidak ditemukan atau kedaluwarsa
        """
        with self.lock:
            cached_data = self.cache.get(key)
            if cached_data is None:
                return None

            if time.time() > cached_data['expiration']:
                del self.cache[key]
                return None

            return cached_data['value']

    def delete(self, key: str) -> None:
        """
        Menghapus item dari cache.
        
        :param key: Kunci yang akan dihapus
        """
        with self.lock:
            if key in self.cache:
                del self.cache[key]

    def clear(self) -> None:
        """Membersihkan seluruh cache."""
        with self.lock:
            self.cache.clear()

    def get_or_set(self, key: str, value_func: callable, expiration: int = None) -> Any:
        """
        Mengambil nilai dari cache jika ada, jika tidak, menyimpan dan mengembalikan nilai baru.
        
        :param key: Kunci untuk mengambil/menyimpan nilai
        :param value_func: Fungsi untuk menghasilkan nilai jika tidak ada dalam cache
        :param expiration: Waktu kedaluwarsa dalam detik (opsional)
        :return: Nilai dari cache atau nilai baru
        """
        value = self.get(key)
        if value is None:
            value = value_func()
            self.set(key, value, expiration)
        return value

# Inisialisasi cache global
cache = SimpleCache()

# Contoh penggunaan:
# from bot.cache import cache
# 
# # Menyimpan data
# cache.set('user_123_balance', 1000.0, 60)  # Simpan selama 60 detik
# 
# # Mengambil data
# balance = cache.get('user_123_balance')
# 
# # Menggunakan get_or_set
# def fetch_user_data(user_id):
#     # Fungsi ini akan dipanggil jika data tidak ada di cache
#     return {'name': 'John Doe', 'balance': 500.0}
# 
# user_data = cache.get_or_set(f'user_{user_id}', lambda: fetch_user_data(user_id), 300)
