# bot/handlers.py
# File ini berisi semua handler untuk bot Telegram

from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes
from config import ADMIN_USER_ID
from database.db_operations import (
    is_user_authorized, add_authorized_user, remove_authorized_user,
    get_all_accounts, add_account, edit_account, delete_account,
    get_all_tokens, add_token, edit_token, delete_token, get_token_by_id, get_account_by_id
)
from bot.cache import cache
from api.coinstore_api import get_account_balance, withdraw
from bot.utils import validate_amount, validate_address
import random
import logging

logger = logging.getLogger(__name__)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk command /start."""
    user_id = update.effective_user.id
    if await is_user_authorized(user_id):
        await update.message.reply_text('Selamat datang! Gunakan /menu untuk melihat opsi yang tersedia.')
    else:
        await update.message.reply_text('Maaf, Anda tidak memiliki izin untuk menggunakan bot ini.')

async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk command /admin."""
    user_id = update.effective_user.id
    if user_id != ADMIN_USER_ID:
        await update.message.reply_text('Anda tidak memiliki izin untuk menggunakan perintah ini.')
        return
    
    keyboard = [
        [InlineKeyboardButton("Tambah Pengguna", callback_data='add_user')],
        [InlineKeyboardButton("Hapus Pengguna", callback_data='remove_user')],
        [InlineKeyboardButton("Reset Cache", callback_data='reset_cache')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text('Menu Admin:', reply_markup=reply_markup)

async def menu_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk command /menu."""
    user_id = update.effective_user.id
    if await is_user_authorized(user_id):
        keyboard = get_main_menu_keyboard()
        await update.message.reply_text('Menu Utama:', reply_markup=keyboard)
    else:
        await update.message.reply_text('Maaf, Anda tidak memiliki izin untuk menggunakan bot ini.')
    
    keyboard = [
        [InlineKeyboardButton("Manajemen Akun", callback_data='account_management')],
        [InlineKeyboardButton("Manajemen Token", callback_data='token_management')],
        [InlineKeyboardButton("Withdraw", callback_data='withdraw')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text('Menu Utama:', reply_markup=reply_markup)

async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk semua callback query dari inline keyboards."""
    query = update.callback_query
    await query.answer()
    user_id = update.effective_user.id

    if not await is_user_authorized(user_id) and query.data not in ['add_user', 'remove_user']:
        await query.edit_message_text('Maaf, Anda tidak memiliki izin untuk menggunakan bot ini.')
        return

    if query.data == 'main_menu':
        await show_main_menu(update, context)
    elif query.data == 'account_management':
        await show_account_management_menu(query, context)
    elif query.data == 'token_management':
        await show_token_management_menu(query, context)
    elif query.data == 'withdraw':
        await start_withdraw_process(query, context)
    elif query.data == 'settings':
        await show_settings_menu(update, context)
    elif query.data == 'view_balance':
        await view_balance(query, context)
    elif query.data == 'reset_cache':
        await reset_cache(query, context)
    
    # Handler untuk aksi admin
    elif query.data in ['add_user', 'remove_user', 'reset_cache']:
        await handle_admin_actions(query, context, user_id)
    
    # Handler untuk manajemen akun
    elif query.data in ['account_management', 'add_account', 'edit_account', 'delete_account', 'view_accounts'] or query.data.startswith(('edit_account_', 'delete_account_')):
        await handle_account_management(query, context, user_id)
    
    # Handler untuk manajemen token
    elif query.data in ['token_management', 'add_token', 'edit_token', 'delete_token', 'view_tokens'] or query.data.startswith(('edit_token_', 'delete_token_')):
        await handle_token_management(query, context, user_id)
    
    # Handler untuk proses withdraw
    elif query.data == 'withdraw' or query.data.startswith(('withdraw_account_', 'withdraw_token_')):
        await handle_withdraw_process(query, context, user_id)

async def handle_admin_actions(query, context: ContextTypes.DEFAULT_TYPE, user_id):
    """Menangani aksi-aksi admin."""
    if user_id != ADMIN_USER_ID:
        await query.edit_message_text('Anda tidak memiliki izin untuk melakukan aksi ini.')
        return

    if query.data == 'add_user':
        context.user_data['admin_action'] = 'add_user'
        await query.edit_message_text("Kirim ID Telegram pengguna yang ingin ditambahkan.")
    elif query.data == 'remove_user':
        context.user_data['admin_action'] = 'remove_user'
        await query.edit_message_text("Kirim ID Telegram pengguna yang ingin dihapus.")
    elif query.data == 'reset_cache':
        cache.clear()
        await query.edit_message_text("Cache telah direset.")

async def handle_account_management(query, context: ContextTypes.DEFAULT_TYPE, user_id):
    """Menangani aksi-aksi manajemen akun."""
    if query.data == 'account_management':
        await show_account_management_menu(query, context)
    elif query.data == 'add_account':
        context.user_data['account_action'] = 'add'
        await query.edit_message_text("Masukkan informasi akun dalam format: nama,api_key,secret_key")
    elif query.data == 'edit_account':
        await show_edit_account_menu(query, context, user_id)
    elif query.data.startswith('edit_account_'):
        account_id = int(query.data.split('_')[2])
        context.user_data['account_action'] = 'edit'
        context.user_data['editing_account'] = account_id
        await query.edit_message_text("Masukkan informasi akun baru dalam format: nama,api_key,secret_key")
    elif query.data == 'delete_account':
        await show_delete_account_menu(query, context, user_id)
    elif query.data.startswith('delete_account_'):
        account_id = int(query.data.split('_')[2])
        await delete_account(user_id, account_id)
        await query.edit_message_text("Akun berhasil dihapus.")
    elif query.data == 'view_accounts':
        await show_all_accounts(query, context, user_id)

async def handle_token_management(query, context: ContextTypes.DEFAULT_TYPE, user_id):
    """Menangani aksi-aksi manajemen token."""
    if query.data == 'token_management':
        await show_token_management_menu(query, context)
    elif query.data == 'add_token':
        context.user_data['token_action'] = 'add'
        await query.edit_message_text("Masukkan informasi token dalam format: nama,simbol")
    elif query.data == 'edit_token':
        await show_edit_token_menu(query, context, user_id)
    elif query.data.startswith('edit_token_'):
        token_id = int(query.data.split('_')[2])
        context.user_data['token_action'] = 'edit'
        context.user_data['editing_token'] = token_id
        await query.edit_message_text("Masukkan informasi token baru dalam format: nama,simbol")
    elif query.data == 'delete_token':
        await show_delete_token_menu(query, context, user_id)
    elif query.data.startswith('delete_token_'):
        token_id = int(query.data.split('_')[2])
        await delete_token(user_id, token_id)
        await query.edit_message_text("Token berhasil dihapus.")
    elif query.data == 'view_tokens':
        await show_all_tokens(query, context, user_id)

async def handle_withdraw_process(query, context: ContextTypes.DEFAULT_TYPE, user_id):
    """Menangani proses withdraw."""
    if query.data == 'withdraw':
        context.user_data['withdraw_state'] = 'select_accounts'
        await show_withdraw_account_selection(query, context, user_id)
    elif query.data.startswith('withdraw_account_'):
        await handle_withdraw_account_selection(query, context, user_id)
    elif query.data == 'withdraw_select_token':
        await show_withdraw_token_selection(query, context, user_id)
    elif query.data.startswith('withdraw_token_'):
        await handle_withdraw_token_selection(query, context)

async def show_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("Manajemen Akun", callback_data='account_management')],
        [InlineKeyboardButton("Manajemen Token", callback_data='token_management')],
        [InlineKeyboardButton("Withdraw", callback_data='withdraw')],
        [InlineKeyboardButton("Pengaturan", callback_data='settings')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.callback_query.edit_message_text('Menu Utama:', reply_markup=reply_markup)

async def show_settings_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("Lihat Saldo", callback_data='view_balance')],
        [InlineKeyboardButton("Reset Cache", callback_data='reset_cache')],
        [InlineKeyboardButton("Kembali ke Menu Utama", callback_data='main_menu')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.callback_query.edit_message_text('Pengaturan:', reply_markup=reply_markup)

async def show_account_management_menu(query, context: ContextTypes.DEFAULT_TYPE):
    """Menampilkan menu manajemen akun."""
    keyboard = [
        [InlineKeyboardButton("Tambah Akun", callback_data='add_account')],
        [InlineKeyboardButton("Edit Akun", callback_data='edit_account')],
        [InlineKeyboardButton("Hapus Akun", callback_data='delete_account')],
        [InlineKeyboardButton("Lihat Akun", callback_data='view_accounts')],
        [InlineKeyboardButton("Kembali ke Menu Utama", callback_data='main_menu')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text('Manajemen Akun:', reply_markup=reply_markup)

async def show_edit_account_menu(query, context: ContextTypes.DEFAULT_TYPE, user_id):
    """Menampilkan menu untuk memilih akun yang akan diedit."""
    accounts = await get_all_accounts(user_id)
    keyboard = [[InlineKeyboardButton(account['name'], callback_data=f"edit_account_{account['id']}")] for account in accounts]
    keyboard.append([InlineKeyboardButton("Kembali ke Manajemen Akun", callback_data='account_management')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text('Pilih akun untuk diedit:', reply_markup=reply_markup)

async def show_delete_account_menu(query, context: ContextTypes.DEFAULT_TYPE, user_id):
    """Menampilkan menu untuk memilih akun yang akan dihapus."""
    accounts = await get_all_accounts(user_id)
    keyboard = [[InlineKeyboardButton(account['name'], callback_data=f"delete_account_{account['id']}")] for account in accounts]
    keyboard.append([InlineKeyboardButton("Kembali ke Manajemen Akun", callback_data='account_management')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text('Pilih akun untuk dihapus:', reply_markup=reply_markup)

async def show_all_accounts(query, context: ContextTypes.DEFAULT_TYPE, user_id):
    """Menampilkan daftar semua akun pengguna."""
    accounts = await get_all_accounts(user_id)
    if accounts:
        account_list = "\n".join([f"{account['name']} (ID: {account['id']})" for account in accounts])
        await query.edit_message_text(f"Daftar akun Anda:\n\n{account_list}")
    else:
        await query.edit_message_text("Anda belum memiliki akun.")

async def show_token_management_menu(query, context: ContextTypes.DEFAULT_TYPE):
    """Menampilkan menu manajemen token."""
    keyboard = [
        [InlineKeyboardButton("Tambah Token", callback_data='add_token')],
        [InlineKeyboardButton("Edit Token", callback_data='edit_token')],
        [InlineKeyboardButton("Hapus Token", callback_data='delete_token')],
        [InlineKeyboardButton("Lihat Token", callback_data='view_tokens')],
        [InlineKeyboardButton("Kembali ke Menu Utama", callback_data='main_menu')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text('Manajemen Token:', reply_markup=reply_markup)

async def show_edit_token_menu(query, context: ContextTypes.DEFAULT_TYPE, user_id):
    """Menampilkan menu untuk memilih token yang akan diedit."""
    tokens = await get_all_tokens(user_id)
    keyboard = [[InlineKeyboardButton(token['symbol'], callback_data=f"edit_token_{token['id']}")] for token in tokens]
    keyboard.append([InlineKeyboardButton("Kembali ke Manajemen Token", callback_data='token_management')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text('Pilih token untuk diedit:', reply_markup=reply_markup)

async def show_delete_token_menu(query, context: ContextTypes.DEFAULT_TYPE, user_id):
    """Menampilkan menu untuk memilih token yang akan dihapus."""
    tokens = await get_all_tokens(user_id)
    keyboard = [[InlineKeyboardButton(token['symbol'], callback_data=f"delete_token_{token['id']}")] for token in tokens]
    keyboard.append([InlineKeyboardButton("Kembali ke Manajemen Token", callback_data='token_management')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text('Pilih token untuk dihapus:', reply_markup=reply_markup)

async def show_all_tokens(query, context: ContextTypes.DEFAULT_TYPE, user_id):
    """Menampilkan daftar semua token pengguna."""
    tokens = await get_all_tokens(user_id)
    if tokens:
        token_list = "\n".join([f"{token['name']} ({token['symbol']}) (ID: {token['id']})" for token in tokens])
        await query.edit_message_text(f"Daftar token Anda:\n\n{token_list}")
    else:
        await query.edit_message_text("Anda belum memiliki token.")

async def show_withdraw_account_selection(query, context: ContextTypes.DEFAULT_TYPE, user_id):
    """Menampilkan menu untuk memilih akun untuk withdraw."""
    accounts = await get_all_accounts(user_id)
    keyboard = [[InlineKeyboardButton(account['name'], callback_data=f"withdraw_account_{account['id']}")] for account in accounts]
    keyboard.append([InlineKeyboardButton("Kembali ke Menu Utama", callback_data='main_menu')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text('Pilih akun untuk withdraw:', reply_markup=reply_markup)

async def handle_withdraw_account_selection(query, context: ContextTypes.DEFAULT_TYPE, user_id):
    """Menangani pemilihan akun untuk withdraw."""
    account_id = int(query.data.split('_')[2])
    if 'selected_accounts' not in context.user_data:
        context.user_data['selected_accounts'] = []
    if account_id not in context.user_data['selected_accounts']:
        context.user_data['selected_accounts'].append(account_id)
    
    accounts = await get_all_accounts(user_id)
    keyboard = [[InlineKeyboardButton(f"{'✅ ' if account['id'] in context.user_data['selected_accounts'] else ''}{account['name']}", 
                                      callback_data=f"withdraw_account_{account['id']}")] for account in accounts]
    keyboard.append([InlineKeyboardButton("Lanjut ke Pemilihan Token", callback_data='withdraw_select_token')])
    keyboard.append([InlineKeyboardButton("Kembali ke Menu Utama", callback_data='main_menu')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text('Pilih akun untuk withdraw (pilih beberapa jika diperlukan):', reply_markup=reply_markup)

async def show_withdraw_token_selection(query, context: ContextTypes.DEFAULT_TYPE, user_id):
    """Menampilkan menu untuk memilih token untuk withdraw."""
    context.user_data['withdraw_state'] = 'select_token'
    tokens = await get_all_tokens(user_id)
    keyboard = [[InlineKeyboardButton(token['symbol'], callback_data=f"withdraw_token_{token['id']}")] for token in tokens]
    keyboard.append([InlineKeyboardButton("Kembali ke Menu Utama", callback_data='main_menu')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text('Pilih token untuk withdraw:', reply_markup=reply_markup)

async def handle_withdraw_token_selection(query, context: ContextTypes.DEFAULT_TYPE):
    """Menangani pemilihan token untuk withdraw."""
    token_id = int(query.data.split('_')[2])
    context.user_data['selected_token'] = token_id
    context.user_data['withdraw_state'] = 'enter_amount'
    await query.edit_message_text('Masukkan jumlah yang ingin di-withdraw (gunakan format: min-max, contoh: 100-500):')

async def message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk semua pesan teks."""
    user_id = update.effective_user.id
    if not await is_user_authorized(user_id) and 'admin_action' not in context.user_data:
        await update.message.reply_text('Maaf, Anda tidak memiliki izin untuk menggunakan bot ini.')
        return

    if 'admin_action' in context.user_data:
        await handle_admin_message(update, context)
    elif 'account_action' in context.user_data:
        await handle_account_message(update, context, user_id)
    elif 'token_action' in context.user_data:
        await handle_token_message(update, context, user_id)
    elif 'withdraw_state' in context.user_data:
        await handle_withdraw_message(update, context, user_id)
    else:
        await update.message.reply_text("Saya tidak mengerti perintah tersebut. Gunakan /menu untuk melihat opsi yang tersedia.")

async def handle_admin_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Menangani pesan untuk aksi admin."""
    try:
        target_user_id = int(update.message.text)
        if context.user_data['admin_action'] == 'add_user':
            await add_authorized_user(target_user_id)
            await update.message.reply_text(f"Pengguna dengan ID {target_user_id} telah ditambahkan.")
        elif context.user_data['admin_action'] == 'remove_user':
            await remove_authorized_user(target_user_id)
            await update.message.reply_text(f"Pengguna dengan ID {target_user_id} telah dihapus.")
        del context.user_data['admin_action']
    except ValueError:
        await update.message.reply_text("ID pengguna harus berupa angka.")

async def handle_account_message(update: Update, context: ContextTypes.DEFAULT_TYPE, user_id):
    """Menangani pesan untuk aksi manajemen akun."""
    try:
        name, api_key, secret_key = update.message.text.split(',')
        if context.user_data['account_action'] == 'add':
            await add_account(user_id, name.strip(), api_key.strip(), secret_key.strip())
            await update.message.reply_text("Akun berhasil ditambahkan.")
        elif context.user_data['account_action'] == 'edit':
            await edit_account(user_id, context.user_data['editing_account'], name.strip(), api_key.strip(), secret_key.strip())
            await update.message.reply_text("Akun berhasil diperbarui.")
        del context.user_data['account_action']
        if 'editing_account' in context.user_data:
            del context.user_data['editing_account']
    except ValueError:
        await update.message.reply_text("Format tidak valid. Gunakan format: nama,api_key,secret_key")

async def handle_token_message(update: Update, context: ContextTypes.DEFAULT_TYPE, user_id):
    """Menangani pesan untuk aksi manajemen token."""
    try:
        name, symbol = update.message.text.split(',')
        if context.user_data['token_action'] == 'add':
            await add_token(user_id, name.strip(), symbol.strip())
            await update.message.reply_text("Token berhasil ditambahkan.")
        elif context.user_data['token_action'] == 'edit':
            await edit_token(user_id, context.user_data['editing_token'], name.strip(), symbol.strip())
            await update.message.reply_text("Token berhasil diperbarui.")
        del context.user_data['token_action']
        if 'editing_token' in context.user_data:
            del context.user_data['editing_token']
    except ValueError:
        await update.message.reply_text("Format tidak valid. Gunakan format: nama,simbol")

async def handle_withdraw_message(update: Update, context: ContextTypes.DEFAULT_TYPE, user_id):
    """Menangani pesan untuk proses withdraw."""
    if context.user_data['withdraw_state'] == 'enter_amount':
        is_valid, error_message = validate_amount(update.message.text)
        if not is_valid:
            await update.message.reply_text(error_message)
            return

        min_amount, max_amount = map(float, update.message.text.split('-'))
        context.user_data['withdraw_amount_range'] = (min_amount, max_amount)
        context.user_data['withdraw_state'] = 'enter_addresses'
        await update.message.reply_text(f"Range jumlah withdraw per alamat: {min_amount} - {max_amount}\nMasukkan alamat-alamat withdraw (satu per baris):")

    elif context.user_data['withdraw_state'] == 'enter_addresses':
        addresses = update.message.text.strip().split('\n')
        parsed_addresses = []

        for address in addresses:
            address = address.strip()
            is_valid, error_message = validate_address(address)
            if not is_valid:
                await update.message.reply_text(f"Alamat tidak valid: {address}. {error_message}")
                return
            parsed_addresses.append(address)

        context.user_data['withdraw_addresses'] = parsed_addresses
        context.user_data['withdraw_state'] = 'confirm'
        
        selected_accounts = context.user_data['selected_accounts']
        selected_token = await get_token_by_id(user_id, context.user_data['selected_token'])
        min_amount, max_amount = context.user_data['withdraw_amount_range']
        
        confirmation_message = f"Konfirmasi Withdraw:\n\n"
        confirmation_message += f"Token: {selected_token['symbol']}\n"
        confirmation_message += f"Range jumlah per alamat: {min_amount} - {max_amount}\n"
        confirmation_message += f"Jumlah alamat: {len(parsed_addresses)}\n"
        confirmation_message += f"\nAkun yang digunakan: {', '.join([str(acc_id) for acc_id in selected_accounts])}\n\n"
        confirmation_message += "Apakah Anda yakin ingin melanjutkan? (ya/tidak)"
        
        await update.message.reply_text(confirmation_message)

    elif context.user_data['withdraw_state'] == 'confirm':
        if update.message.text.lower() == 'ya':
            try:
                selected_accounts = context.user_data['selected_accounts']
                selected_token = await get_token_by_id(user_id, context.user_data['selected_token'])
                addresses = context.user_data['withdraw_addresses']
                min_amount, max_amount = context.user_data['withdraw_amount_range']
                
                for account_id in selected_accounts:
                    account = await get_account_by_id(user_id, account_id)
                    total_amount = 0
                    
                    await update.message.reply_text(f"Withdraw untuk akun {account['name']}:")
                    for address in addresses:
                        amount = round(random.uniform(min_amount, max_amount), 8)
                        total_amount += amount
                        result = await withdraw(account['api_key'], account['secret_key'], selected_token['symbol'], amount, address)
                        await update.message.reply_text(f"- Ke alamat {address}: "
                                                        f"Jumlah: {amount} {selected_token['symbol']}. ID Transaksi: {result['id']}")
                    
                    await update.message.reply_text(f"Total withdraw untuk akun {account['name']}: {total_amount} {selected_token['symbol']}")
                
                clear_withdraw_data(context)
            except Exception as e:
                await update.message.reply_text(f"Terjadi kesalahan saat melakukan withdraw: {str(e)}")
        else:
            await update.message.reply_text("Withdraw dibatalkan.")
            clear_withdraw_data(context)

def clear_withdraw_data(context: ContextTypes.DEFAULT_TYPE):
    """Membersihkan data withdraw dari user_data."""
    keys_to_delete = ['withdraw_state', 'selected_accounts', 'selected_token', 'withdraw_amount', 'withdraw_address']
    for key in keys_to_delete:
        if key in context.user_data:
            del context.user_data[key]

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    help_text = """
    Selamat datang di Bot Withdrawal!
    
    Perintah yang tersedia:
    /start - Memulai bot
    /menu - Menampilkan menu utama
    /help - Menampilkan pesan bantuan ini
    
    Gunakan menu untuk mengakses fitur-fitur berikut:
    - Manajemen Akun
    - Manajemen Token
    - Withdraw
    - Pengaturan
    
    Untuk bantuan lebih lanjut, silakan hubungi admin.
    """
    await update.message.reply_text(help_text)

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Menangani error yang terjadi selama eksekusi bot."""
    logger.error(f"Error occurred: {context.error}")
    if update.effective_message:
        await update.effective_message.reply_text("Terjadi kesalahan. Mohon coba lagi nanti atau hubungi admin.")
