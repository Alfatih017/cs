from telegram import Update
from telegram.ext import ContextTypes
from bot.keyboards import get_main_menu_keyboard

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text('Selamat datang di Bot Withdrawal! Gunakan /menu untuk melihat opsi yang tersedia.')

async def menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = get_main_menu_keyboard()
    await update.message.reply_text('Menu Utama:', reply_markup=keyboard)

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    help_text = """
    Selamat datang di Bot Withdrawal!
    
    Perintah yang tersedia:
    /start - Memulai bot
    /menu - Menampilkan menu utama
    /help - Menampilkan pesan bantuan ini
    
    Gunakan menu untuk mengakses fitur-fitur berikut:
    - Manajemen Akun
    - Manajemen Token
    - Withdraw
    - Pengaturan
    
    Untuk bantuan lebih lanjut, silakan hubungi admin.
    """
    await update.message.reply_text(help_text)
