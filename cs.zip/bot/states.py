# bot/states.py

from telegram.ext import ConversationHandler

# States untuk proses withdraw
SELECTING_ACCOUNTS = 1
SELECTING_TOKEN = 2
ENTERING_AMOUNT = 3
ENTERING_ADDRESSES = 4
CONFIRMING = 5

# States untuk manajemen akun
ADDING_ACCOUNT = 11
EDITING_ACCOUNT = 12
DELETING_ACCOUNT = 13

# States untuk manajemen token
ADDING_TOKEN = 21
EDITING_TOKEN = 22
DELETING_TOKEN = 23

# States untuk admin actions
ADDING_USER = 31
REMOVING_USER = 32

# Definisi state flow untuk withdraw
withdraw_states = {
    SELECTING_ACCOUNTS: [SELECTING_TOKEN],
    SELECTING_TOKEN: [ENTERING_AMOUNT],
    ENTERING_AMOUNT: [ENTERING_ADDRESSES],
    ENTERING_ADDRESSES: [CONFIRMING],
    CONFIRMING: [ConversationHandler.END]
}

# Fungsi helper untuk mendapatkan next state
def get_next_state(current_state):
    return withdraw_states.get(current_state, [ConversationHandler.END])[0]