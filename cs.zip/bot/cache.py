# bot/cache.py
# File ini berisi implementasi sistem caching sederhana

import time

class SimpleCache:
    """Implementasi cache sederhana dengan waktu kedaluwarsa."""

    def __init__(self, expiration=300):
        self.cache = {}
        self.expiration = expiration

    def set(self, key, value):
        """Menyimpan nilai dalam cache dengan timestamp."""
        self.cache[key] = {
            'value': value,
            'timestamp': time.time()
        }

    def get(self, key):
        """Mengambil nilai dari cache jika masih valid."""
        if key in self.cache:
            if time.time() - self.cache[key]['timestamp'] < self.expiration:
                return self.cache[key]['value']
            else:
                del self.cache[key]
        return None

    def clear(self):
        """Membersihkan seluruh cache."""
        self.cache.clear()

# Inisialisasi cache
cache = SimpleCache(CACHE_EXPIRATION)