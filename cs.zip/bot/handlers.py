# bot/handlers.py
# File ini berisi semua handler untuk bot Telegram

from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import CallbackContext
from config import ADMIN_USER_ID
from database.db_operations import (
    is_user_authorized, add_authorized_user, remove_authorized_user,
    get_all_accounts, add_account, edit_account, delete_account,
    get_all_tokens, add_token, edit_token, delete_token
)
from bot.cache import cache
from bot.coinstore_api import get_account_balance, withdraw
from bot.utils import validate_amount, validate_address
import random

def start(update: Update, context: CallbackContext):
    """Handler untuk command /start."""
    user_id = update.effective_user.id
    if is_user_authorized(user_id):
        update.message.reply_text('Selamat datang! Gunakan /menu untuk melihat opsi yang tersedia.')
    else:
        update.message.reply_text('Maaf, Anda tidak memiliki izin untuk menggunakan bot ini.')

def admin_command(update: Update, context: CallbackContext):
    """Handler untuk command /admin."""
    user_id = update.effective_user.id
    if user_id != ADMIN_USER_ID:
        update.message.reply_text('Anda tidak memiliki izin untuk menggunakan perintah ini.')
        return
    
    keyboard = [
        [InlineKeyboardButton("Tambah Pengguna", callback_data='add_user')],
        [InlineKeyboardButton("Hapus Pengguna", callback_data='remove_user')],
        [InlineKeyboardButton("Reset Cache", callback_data='reset_cache')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    update.message.reply_text('Menu Admin:', reply_markup=reply_markup)

def menu_command(update: Update, context: CallbackContext):
    """Handler untuk command /menu."""
    user_id = update.effective_user.id
    if not is_user_authorized(user_id):
        update.message.reply_text('Maaf, Anda tidak memiliki izin untuk menggunakan bot ini.')
        return
    
    keyboard = [
        [InlineKeyboardButton("Manajemen Akun", callback_data='account_management')],
        [InlineKeyboardButton("Manajemen Token", callback_data='token_management')],
        [InlineKeyboardButton("Withdraw", callback_data='withdraw')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    update.message.reply_text('Menu Utama:', reply_markup=reply_markup)

def callback_handler(update: Update, context: CallbackContext):
    """Handler untuk semua callback query dari inline keyboards."""
    query = update.callback_query
    query.answer()
    user_id = update.effective_user.id
    if not is_user_authorized(user_id) and query.data not in ['add_user', 'remove_user']:
        query.edit_message_text('Maaf, Anda tidak memiliki izin untuk menggunakan bot ini.')
        return
    if query.data == 'main_menu':
        show_main_menu(update, context)
    elif query.data == 'account_management':
        show_account_management_menu(query, context)
    elif query.data == 'token_management':
        show_token_management_menu(query, context)
    elif query.data == 'withdraw':
        start_withdraw_process(query, context)
    elif query.data == 'settings':
        show_settings_menu(update, context)
    elif query.data == 'view_balance':
        view_balance(query, context)
    elif query.data == 'reset_cache':
        reset_cache(query, context)
        
    # Handler untuk aksi admin
    if query.data in ['add_user', 'remove_user', 'reset_cache']:
        handle_admin_actions(query, context, user_id)
    
    # Handler untuk manajemen akun
    elif query.data in ['account_management', 'add_account', 'edit_account', 'delete_account', 'view_accounts'] or query.data.startswith(('edit_account_', 'delete_account_')):
        handle_account_management(query, context, user_id)
    
    # Handler untuk manajemen token
    elif query.data in ['token_management', 'add_token', 'edit_token', 'delete_token', 'view_tokens'] or query.data.startswith(('edit_token_', 'delete_token_')):
        handle_token_management(query, context, user_id)
    
    # Handler untuk proses withdraw
    elif query.data == 'withdraw' or query.data.startswith(('withdraw_account_', 'withdraw_token_')):
        handle_withdraw_process(query, context, user_id)
    
    # Handler untuk kembali ke menu utama
    elif query.data == 'main_menu':
        show_main_menu(query)

def handle_admin_actions(query, context, user_id):
    """Menangani aksi-aksi admin."""
    if user_id != ADMIN_USER_ID:
        query.edit_message_text('Anda tidak memiliki izin untuk melakukan aksi ini.')
        return

    if query.data == 'add_user':
        context.user_data['admin_action'] = 'add_user'
        query.edit_message_text("Kirim ID Telegram pengguna yang ingin ditambahkan.")
    elif query.data == 'remove_user':
        context.user_data['admin_action'] = 'remove_user'
        query.edit_message_text("Kirim ID Telegram pengguna yang ingin dihapus.")
    elif query.data == 'reset_cache':
        cache.clear()
        query.edit_message_text("Cache telah direset.")

def handle_account_management(query, context, user_id):
    """Menangani aksi-aksi manajemen akun."""
    if query.data == 'account_management':
        show_account_management_menu(query)
    elif query.data == 'add_account':
        context.user_data['account_action'] = 'add'
        query.edit_message_text("Masukkan informasi akun dalam format: nama,api_key,secret_key")
    elif query.data == 'edit_account':
        show_edit_account_menu(query, user_id)
    elif query.data.startswith('edit_account_'):
        account_id = int(query.data.split('_')[2])
        context.user_data['account_action'] = 'edit'
        context.user_data['editing_account'] = account_id
        query.edit_message_text("Masukkan informasi akun baru dalam format: nama,api_key,secret_key")
    elif query.data == 'delete_account':
        show_delete_account_menu(query, user_id)
    elif query.data.startswith('delete_account_'):
        account_id = int(query.data.split('_')[2])
        delete_account(user_id, account_id)
        query.edit_message_text("Akun berhasil dihapus.")
    elif query.data == 'view_accounts':
        show_all_accounts(query, user_id)

def handle_token_management(query, context, user_id):
    """Menangani aksi-aksi manajemen token."""
    if query.data == 'token_management':
        show_token_management_menu(query)
    elif query.data == 'add_token':
        context.user_data['token_action'] = 'add'
        query.edit_message_text("Masukkan informasi token dalam format: nama,simbol")
    elif query.data == 'edit_token':
        show_edit_token_menu(query, user_id)
    elif query.data.startswith('edit_token_'):
        token_id = int(query.data.split('_')[2])
        context.user_data['token_action'] = 'edit'
        context.user_data['editing_token'] = token_id
        query.edit_message_text("Masukkan informasi token baru dalam format: nama,simbol")
    elif query.data == 'delete_token':
        show_delete_token_menu(query, user_id)
    elif query.data.startswith('delete_token_'):
        token_id = int(query.data.split('_')[2])
        delete_token(user_id, token_id)
        query.edit_message_text("Token berhasil dihapus.")
    elif query.data == 'view_tokens':
        show_all_tokens(query, user_id)

def handle_withdraw_process(query, context, user_id):
    """Menangani proses withdraw."""
    if query.data == 'withdraw':
        context.user_data['withdraw_state'] = 'select_accounts'
        show_withdraw_account_selection(query, user_id)
    elif query.data.startswith('withdraw_account_'):
        handle_withdraw_account_selection(query, context, user_id)
    elif query.data == 'withdraw_select_token':
        show_withdraw_token_selection(query, context, user_id)
    elif query.data.startswith('withdraw_token_'):
        handle_withdraw_token_selection(query, context)

def show_main_menu(update: Update, context: CallbackContext):
    keyboard = [
        [InlineKeyboardButton("Manajemen Akun", callback_data='account_management')],
        [InlineKeyboardButton("Manajemen Token", callback_data='token_management')],
        [InlineKeyboardButton("Withdraw", callback_data='withdraw')],
        [InlineKeyboardButton("Pengaturan", callback_data='settings')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    update.message.reply_text('Menu Utama:', reply_markup=reply_markup)

def show_settings_menu(update: Update, context: CallbackContext):
    keyboard = [
        [InlineKeyboardButton("Lihat Saldo", callback_data='view_balance')],
        [InlineKeyboardButton("Reset Cache", callback_data='reset_cache')],
        [InlineKeyboardButton("Kembali ke Menu Utama", callback_data='main_menu')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    update.callback_query.edit_message_text('Pengaturan:', reply_markup=reply_markup)

# bot/handlers.py (lanjutan)

def show_account_management_menu(query):
    """Menampilkan menu manajemen akun."""
    keyboard = [
        [InlineKeyboardButton("Tambah Akun", callback_data='add_account')],
        [InlineKeyboardButton("Edit Akun", callback_data='edit_account')],
        [InlineKeyboardButton("Hapus Akun", callback_data='delete_account')],
        [InlineKeyboardButton("Lihat Akun", callback_data='view_accounts')],
        [InlineKeyboardButton("Kembali ke Menu Utama", callback_data='main_menu')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    query.edit_message_text('Manajemen Akun:', reply_markup=reply_markup)

def show_edit_account_menu(query, user_id):
    """Menampilkan menu untuk memilih akun yang akan diedit."""
    accounts = get_all_accounts(user_id)
    keyboard = [[InlineKeyboardButton(account['name'], callback_data=f"edit_account_{account['id']}")] for account in accounts]
    keyboard.append([InlineKeyboardButton("Kembali ke Manajemen Akun", callback_data='account_management')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    query.edit_message_text('Pilih akun untuk diedit:', reply_markup=reply_markup)

def show_delete_account_menu(query, user_id):
    """Menampilkan menu untuk memilih akun yang akan dihapus."""
    accounts = get_all_accounts(user_id)
    keyboard = [[InlineKeyboardButton(account['name'], callback_data=f"delete_account_{account['id']}")] for account in accounts]
    keyboard.append([InlineKeyboardButton("Kembali ke Manajemen Akun", callback_data='account_management')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    query.edit_message_text('Pilih akun untuk dihapus:', reply_markup=reply_markup)

def show_all_accounts(query, user_id):
    """Menampilkan daftar semua akun pengguna."""
    accounts = get_all_accounts(user_id)
    if accounts:
        account_list = "\n".join([f"{account['name']} (ID: {account['id']})" for account in accounts])
        query.edit_message_text(f"Daftar akun Anda:\n\n{account_list}")
    else:
        query.edit_message_text("Anda belum memiliki akun.")

def show_token_management_menu(query):
    """Menampilkan menu manajemen token."""
    keyboard = [
        [InlineKeyboardButton("Tambah Token", callback_data='add_token')],
        [InlineKeyboardButton("Edit Token", callback_data='edit_token')],
        [InlineKeyboardButton("Hapus Token", callback_data='delete_token')],
        [InlineKeyboardButton("Lihat Token", callback_data='view_tokens')],
        [InlineKeyboardButton("Kembali ke Menu Utama", callback_data='main_menu')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    query.edit_message_text('Manajemen Token:', reply_markup=reply_markup)

def show_edit_token_menu(query, user_id):
    """Menampilkan menu untuk memilih token yang akan diedit."""
    tokens = get_all_tokens(user_id)
    keyboard = [[InlineKeyboardButton(token['symbol'], callback_data=f"edit_token_{token['id']}")] for token in tokens]
    keyboard.append([InlineKeyboardButton("Kembali ke Manajemen Token", callback_data='token_management')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    query.edit_message_text('Pilih token untuk diedit:', reply_markup=reply_markup)

def show_delete_token_menu(query, user_id):
    """Menampilkan menu untuk memilih token yang akan dihapus."""
    tokens = get_all_tokens(user_id)
    keyboard = [[InlineKeyboardButton(token['symbol'], callback_data=f"delete_token_{token['id']}")] for token in tokens]
    keyboard.append([InlineKeyboardButton("Kembali ke Manajemen Token", callback_data='token_management')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    query.edit_message_text('Pilih token untuk dihapus:', reply_markup=reply_markup)

def show_all_tokens(query, user_id):
    """Menampilkan daftar semua token pengguna."""
    tokens = get_all_tokens(user_id)
    if tokens:
        token_list = "\n".join([f"{token['name']} ({token['symbol']}) (ID: {token['id']})" for token in tokens])
        query.edit_message_text(f"Daftar token Anda:\n\n{token_list}")
    else:
        query.edit_message_text("Anda belum memiliki token.")

def show_withdraw_account_selection(query, user_id):
    """Menampilkan menu untuk memilih akun untuk withdraw."""
    accounts = get_all_accounts(user_id)
    keyboard = [[InlineKeyboardButton(account['name'], callback_data=f"withdraw_account_{account['id']}")] for account in accounts]
    keyboard.append([InlineKeyboardButton("Kembali ke Menu Utama", callback_data='main_menu')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    query.edit_message_text('Pilih akun untuk withdraw:', reply_markup=reply_markup)

def handle_withdraw_account_selection(query, context, user_id):
    """Menangani pemilihan akun untuk withdraw."""
    account_id = int(query.data.split('_')[2])
    if 'selected_accounts' not in context.user_data:
        context.user_data['selected_accounts'] = []
    if account_id not in context.user_data['selected_accounts']:
        context.user_data['selected_accounts'].append(account_id)
    
    accounts = get_all_accounts(user_id)
    keyboard = [[InlineKeyboardButton(f"{'✅ ' if account['id'] in context.user_data['selected_accounts'] else ''}{account['name']}", 
                                      callback_data=f"withdraw_account_{account['id']}")] for account in accounts]
    keyboard.append([InlineKeyboardButton("Lanjut ke Pemilihan Token", callback_data='withdraw_select_token')])
    keyboard.append([InlineKeyboardButton("Kembali ke Menu Utama", callback_data='main_menu')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    query.edit_message_text('Pilih akun untuk withdraw (pilih beberapa jika diperlukan):', reply_markup=reply_markup)

def show_withdraw_token_selection(query, context, user_id):
    """Menampilkan menu untuk memilih token untuk withdraw."""
    context.user_data['withdraw_state'] = 'select_token'
    tokens = get_all_tokens(user_id)
    keyboard = [[InlineKeyboardButton(token['symbol'], callback_data=f"withdraw_token_{token['id']}")] for token in tokens]
    keyboard.append([InlineKeyboardButton("Kembali ke Menu Utama", callback_data='main_menu')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    query.edit_message_text('Pilih token untuk withdraw:', reply_markup=reply_markup)

def handle_withdraw_token_selection(query, context):
    """Menangani pemilihan token untuk withdraw."""
    token_id = int(query.data.split('_')[2])
    context.user_data['selected_token'] = token_id
    context.user_data['withdraw_state'] = 'enter_amount'
    query.edit_message_text('Masukkan jumlah yang ingin di-withdraw (gunakan format: min-max, contoh: 100-500):')

def message_handler(update: Update, context: CallbackContext):
    """Handler untuk semua pesan teks."""
    user_id = update.effective_user.id
    if not is_user_authorized(user_id) and 'admin_action' not in context.user_data:
        update.message.reply_text('Maaf, Anda tidak memiliki izin untuk menggunakan bot ini.')
        return

    if 'admin_action' in context.user_data:
        handle_admin_message(update, context)
    elif 'account_action' in context.user_data:
        handle_account_message(update, context, user_id)
    elif 'token_action' in context.user_data:
        handle_token_message(update, context, user_id)
    elif 'withdraw_state' in context.user_data:
        handle_withdraw_message(update, context, user_id)
    else:
        update.message.reply_text("Saya tidak mengerti perintah tersebut. Gunakan /menu untuk melihat opsi yang tersedia.")

def handle_admin_message(update: Update, context: CallbackContext):
    """Menangani pesan untuk aksi admin."""
    try:
        target_user_id = int(update.message.text)
        if context.user_data['admin_action'] == 'add_user':
            add_authorized_user(target_user_id)
            update.message.reply_text(f"Pengguna dengan ID {target_user_id} telah ditambahkan.")
        elif context.user_data['admin_action'] == 'remove_user':
            remove_authorized_user(target_user_id)
            update.message.reply_text(f"Pengguna dengan ID {target_user_id} telah dihapus.")
        del context.user_data['admin_action']
    except ValueError:
        update.message.reply_text("ID pengguna harus berupa angka.")

def handle_account_message(update: Update, context: CallbackContext, user_id):
    """Menangani pesan untuk aksi manajemen akun."""
    try:
        name, api_key, secret_key = update.message.text.split(',')
        if context.user_data['account_action'] == 'add':
            add_account(user_id, name.strip(), api_key.strip(), secret_key.strip())
            update.message.reply_text("Akun berhasil ditambahkan.")
        elif context.user_data['account_action'] == 'edit':
            edit_account(user_id, context.user_data['editing_account'], name.strip(), api_key.strip(), secret_key.strip())
            update.message.reply_text("Akun berhasil diperbarui.")
        del context.user_data['account_action']
        if 'editing_account' in context.user_data:
            del context.user_data['editing_account']
    except ValueError:
        update.message.reply_text("Format tidak valid. Gunakan format: nama,api_key,secret_key")

def handle_token_message(update: Update, context: CallbackContext, user_id):
    """Menangani pesan untuk aksi manajemen token."""
    try:
        name, symbol = update.message.text.split(',')
        if context.user_data['token_action'] == 'add':
            add_token(user_id, name.strip(), symbol.strip())
            update.message.reply_text("Token berhasil ditambahkan.")
        elif context.user_data['token_action'] == 'edit':
            edit_token(user_id, context.user_data['editing_token'], name.strip(), symbol.strip())
            update.message.reply_text("Token berhasil diperbarui.")
        del context.user_data['token_action']
        if 'editing_token' in context.user_data:
            del context.user_data['editing_token']
    except ValueError:
        update.message.reply_text("Format tidak valid. Gunakan format: nama,simbol")

def handle_withdraw_message(update: Update, context: CallbackContext, user_id):
    """Menangani pesan untuk proses withdraw."""
    if context.user_data['withdraw_state'] == 'enter_amount':
        is_valid, error_message = validate_amount(update.message.text)
        if not is_valid:
            update.message.reply_text(error_message)
            return

        min_amount, max_amount = map(float, update.message.text.split('-'))
        context.user_data['withdraw_amount_range'] = (min_amount, max_amount)
        context.user_data['withdraw_state'] = 'enter_addresses'
        update.message.reply_text(f"Range jumlah withdraw per alamat: {min_amount} - {max_amount}\nMasukkan alamat-alamat withdraw (satu per baris):")

    elif context.user_data['withdraw_state'] == 'enter_addresses':
        addresses = update.message.text.strip().split('\n')
        parsed_addresses = []

        for address in addresses:
            address = address.strip()
            is_valid, error_message = validate_address(address)
            if not is_valid:
                update.message.reply_text(f"Alamat tidak valid: {address}. {error_message}")
                return
            parsed_addresses.append(address)

        # Menghapus validasi jumlah minimal alamat
        context.user_data['withdraw_addresses'] = parsed_addresses
        context.user_data['withdraw_state'] = 'confirm'
        
        selected_accounts = context.user_data['selected_accounts']
        selected_token = get_token_by_id(user_id, context.user_data['selected_token'])
        min_amount, max_amount = context.user_data['withdraw_amount_range']
        
        confirmation_message = f"Konfirmasi Withdraw:\n\n"
        confirmation_message += f"Token: {selected_token['symbol']}\n"
        confirmation_message += f"Range jumlah per alamat: {min_amount} - {max_amount}\n"
        confirmation_message += f"Jumlah alamat: {len(parsed_addresses)}\n"
        confirmation_message += f"\nAkun yang digunakan: {', '.join([str(acc_id) for acc_id in selected_accounts])}\n\n"
        confirmation_message += "Apakah Anda yakin ingin melanjutkan? (ya/tidak)"
        
        update.message.reply_text(confirmation_message)

    elif context.user_data['withdraw_state'] == 'confirm':
        if update.message.text.lower() == 'ya':
            try:
                selected_accounts = context.user_data['selected_accounts']
                selected_token = get_token_by_id(user_id, context.user_data['selected_token'])
                addresses = context.user_data['withdraw_addresses']
                min_amount, max_amount = context.user_data['withdraw_amount_range']
                
                for account_id in selected_accounts:
                    account = get_account_by_id(user_id, account_id)
                    total_amount = 0
                    
                    update.message.reply_text(f"Withdraw untuk akun {account['name']}:")
                    for address in addresses:
                        amount = round(random.uniform(min_amount, max_amount), 8)
                        total_amount += amount
                        result = withdraw(account['api_key'], account['secret_key'], selected_token['symbol'], amount, address)
                        update.message.reply_text(f"- Ke alamat {address}: "
                                                  f"Jumlah: {amount} {selected_token['symbol']}. ID Transaksi: {result['id']}")
                    
                    update.message.reply_text(f"Total withdraw untuk akun {account['name']}: {total_amount} {selected_token['symbol']}")
                
                clear_withdraw_data(context)
            except Exception as e:
                update.message.reply_text(f"Terjadi kesalahan saat melakukan withdraw: {str(e)}")
        else:
            update.message.reply_text("Withdraw dibatalkan.")
            clear_withdraw_data(context)

def clear_withdraw_data(context):
    """Membersihkan data withdraw dari user_data."""
    keys_to_delete = ['withdraw_state', 'selected_accounts', 'selected_token', 'withdraw_amount', 'withdraw_address']
    for key in keys_to_delete:
        if key in context.user_data:
            del context.user_data[key]

def help_command(update: Update, context: CallbackContext):
    help_text = """
    Selamat datang di Bot Withdrawal!
    
    Perintah yang tersedia:
    /start - Memulai bot
    /menu - Menampilkan menu utama
    /help - Menampilkan pesan bantuan ini
    
    Gunakan menu untuk mengakses fitur-fitur berikut:
    - Manajemen Akun
    - Manajemen Token
    - Withdraw
    - Pengaturan
    
    Untuk bantuan lebih lanjut, silakan hubungi admin.
    """
    update.message.reply_text(help_text)


def error_handler(update: Update, context: CallbackContext):
    """Menangani error yang terjadi selama eksekusi bot."""
    logger.error(f"Error occurred: {context.error}")
    if update.effective_message:
        update.effective_message.reply_text("Terjadi kesalahan. Mohon coba lagi nanti atau hubungi admin.")