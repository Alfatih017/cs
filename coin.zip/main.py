# main.py

import asyncio
import logging
from telegram import Update
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters
from config import TELEGRAM_BOT_TOKEN
from database.db_operations import init_db
from bot.handlers import (
    start, 
    menu_command, 
    admin_command, 
    help_command, 
    callback_handler, 
    message_handler, 
    error_handler
)

# Konfigurasi logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

async def setup():
    """Melakukan setup awal, termasuk inisialisasi database."""
    await init_db()
    logger.info("Database initialized")

async def main():
    """Fungsi utama untuk menjalankan bot."""
    # Inisialisasi aplikasi
    application = Application.builder().token(TELEGRAM_BOT_TOKEN).build()

    # Menambahkan handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("menu", menu_command))
    application.add_handler(CommandHandler("admin", admin_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CallbackQueryHandler(callback_handler))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, message_handler))

    # Menambahkan error handler
    application.add_error_handler(error_handler)

    # Menjalankan setup awal
    await setup()

    # Memulai polling
    await application.initialize()
    await application.start()
    await application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    asyncio.run(main())
